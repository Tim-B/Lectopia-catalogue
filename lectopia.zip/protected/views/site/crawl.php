<?php
$this->pageTitle = 'Lectopia Crawler';

echo $this->vars['message'];